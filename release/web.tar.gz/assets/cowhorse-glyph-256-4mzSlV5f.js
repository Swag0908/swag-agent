const o="/brand/cowhorse-glyph-256.png";export{o as _};
